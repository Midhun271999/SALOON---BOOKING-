-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 23, 2021 at 06:49 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `beauty`
--

-- --------------------------------------------------------

--
-- Table structure for table `beautition`
--

CREATE TABLE IF NOT EXISTS `beautition` (
  `bid` int(50) NOT NULL AUTO_INCREMENT,
  `pname` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `phno` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `experience` varchar(50) NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `beautition`
--

INSERT INTO `beautition` (`bid`, `pname`, `name`, `qualification`, `phno`, `email`, `address`, `experience`) VALUES
(5, 'chithranjali', 'shiva', 'degree', '9455667587', 'jerinmathai04@gmail.com', 'gf', '1'),
(6, 'lookme', 'tintu', 'degree', '7034767635', 'tintu@gmail.com', 'rajakkad', '3'),
(7, 'lookme', 'sanisha', 'degree', '5467867875', 'sanisha@gmail.com', 'gff', '3'),
(8, 'Vandana', 'Bindu', 'kjn', '7894561230', 'bindu@gmail.com', 'jn', 'hjhnj'),
(9, 'Vandana', 'Nimmi', 'jh', '8547962130', 'nimmi@gmail.com', 'jn', 'kjn');

-- --------------------------------------------------------

--
-- Table structure for table `beautitionbook`
--

CREATE TABLE IF NOT EXISTS `beautitionbook` (
  `bookid` int(50) NOT NULL AUTO_INCREMENT,
  `bookpersonname` varchar(50) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phno` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL,
  `status` int(50) NOT NULL,
  PRIMARY KEY (`bookid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `beautitionbook`
--

INSERT INTO `beautitionbook` (`bookid`, `bookpersonname`, `pname`, `name`, `phno`, `date`, `time`, `status`) VALUES
(3, 'gvbhj', 'chithranjali', 'shiva', '9445667867', '2019-08-01', '2:10', 1),
(4, 'ss', 'chithranjali', 'shiva', '987654567', '2019-01-01', '2:10', 0),
(5, 'lll', '', 'tintu', '8954761230', '2021-02-24', '9am', 0),
(6, 'klml', 'lookme', 'tintu', '9865741023', '2021-02-24', '11 am', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customerreg`
--

CREATE TABLE IF NOT EXISTS `customerreg` (
  `cid` int(50) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `phno` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirmpassword` varchar(50) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `customerreg`
--

INSERT INTO `customerreg` (`cid`, `firstname`, `lastname`, `dob`, `gender`, `phno`, `username`, `password`, `confirmpassword`) VALUES
(1, 'rehna', 'madhav', '2011', 'male', '36475868798', 'rehna', '123', '123'),
(3, 'sreekanmani', 'ram', '2011', ' female', '9878655645', 'sreekanmani', '123', '123'),
(4, 'manu', 'hoc', '2009', 'male', '37586909', 'manu', '1234', '1234'),
(6, 'keerthi', 'hkdgl', '1997', ' female', '653768798', 'keerthi', '1234', '1234'),
(8, 'catherin', 'gfta', '', 'male', '12324356', 'aa', 'aa', 'aa'),
(9, 'ee', 'ggk', '2011', ' female', '8606132858', 'aa', '123', '123'),
(10, 'jeffrey', 'gabriel', '1983', 'male', '8848686647', 'jef', '0000', '0000'),
(11, 'ann', 'anna', '1978', ' female', '8596471230', 'ann', 'ann', 'ann');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `fid` int(50) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `cid` int(50) NOT NULL,
  `Feedback` varchar(50) NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fid`, `Date`, `cid`, `Feedback`) VALUES
(19, '0000-00-00', 6, 'good');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `lid` int(50) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(100) NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`lid`, `username`, `password`, `usertype`) VALUES
(1, 'admin', '123', 'admin'),
(3, 'keerthi', '1234', 'customer'),
(14, 'rose', '1234', 'parlour'),
(18, 'chamayam', '555', 'parlour'),
(19, 'aaaaaa', '1234', 'saloon'),
(20, 'yoyo', '4444', 'saloon'),
(21, '4444', 'hair-care8.jpg', 'saloon'),
(22, 'lookme', '1414', 'parlour'),
(23, 'vandana', 'vandana', 'parlour'),
(24, 'ann', 'ann', 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `parlour`
--

CREATE TABLE IF NOT EXISTS `parlour` (
  `pid` int(50) NOT NULL AUTO_INCREMENT,
  `pname` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `phno` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `lisence` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `parlour`
--

INSERT INTO `parlour` (`pid`, `pname`, `type`, `phno`, `email`, `location`, `address`, `lisence`, `username`, `password`) VALUES
(4, 'chithranjali', ' both', '34576', 'vava@gmail.com', 'irinjalkuda', 'dbhuh', '12776', 'chithranjali', '12'),
(5, 'romieo', ' both', '9887667856', 'vava@gmail.com', 'kadavandhra', 'kochi kadavandhra', '6578', 'aaa', '12345'),
(7, 'rose', ' female', '1234567809', 'anumoljoseph@gmail.com', 'rajakkad', 'rajakkad', '2132', 'rose', '1234'),
(8, 'lavander', ' both', '1234432109', 'lav@GMAIL.COM', 'rajakkad', 'RAJAKKAD', '11111', 'LAV', '2211'),
(9, 'chamayam', ' female', '1111111111', 'chamayam@gmail.com', 'rajakumary', 'rajakumary', '123', 'chamayam', '555'),
(10, 'lookme', ' female', '4545454545', 'look@gmail.com', 'kakkanad', 'kochi', '4343', 'lookme', '1414'),
(11, 'Vandana', ' female', '8956471023', 'vandana@gmail.com', 'aluva', 'byepass', 'jhn251', 'vandana', 'vandana');

-- --------------------------------------------------------

--
-- Table structure for table `parlourbooking`
--

CREATE TABLE IF NOT EXISTS `parlourbooking` (
  `pbid` int(50) NOT NULL AUTO_INCREMENT,
  `bname` varchar(50) NOT NULL,
  `phno` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL,
  `status` int(50) NOT NULL,
  `beaut` varchar(50) NOT NULL,
  PRIMARY KEY (`pbid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `parlourbooking`
--

INSERT INTO `parlourbooking` (`pbid`, `bname`, `phno`, `location`, `pname`, `date`, `time`, `status`, `beaut`) VALUES
(6, 'kukku', '', 'irinjalkuda', 'romieo', '2019-04-04', '3', 1, ''),
(9, 'riya', '', 'irinjalkuda', 'romieo', '2019-03-07', '3', 1, ''),
(10, 'sam', '9048857540', 'irinjalkuda', 'romieo', '2019-02-02', '2', 1, ''),
(11, 'keerthi', '653768798', 'irinjalkuda', 'chithranjali', '2019-02-06', '4', 1, ''),
(12, 'keerthi', '9562301478', 'irinjalkuda', '', '2021-02-24', '9am', 0, ''),
(13, 'kkk', '09562301478', 'irinjalkuda', '', '2021-02-24', '9am', 0, ''),
(14, 'mm', '07356777874', '', '', '2021-02-24', '9am', 0, ''),
(15, 'lll', '8954761230', 'kakkanad', '', '2021-02-24', '9am', 0, ''),
(16, 'klml', '9865741023', 'kakkanad', 'lookme', '2021-02-24', '11 am', 0, ''),
(17, 'ann', '8956471230', 'aluva', 'Vandana', '2021-02-24', '9am', 1, 'Nimmi'),
(18, 'ann', '8956471230', 'aluva', 'Vandana', '2021-02-24', '9am', 1, 'Nimmi');

-- --------------------------------------------------------

--
-- Table structure for table `salonebooking`
--

CREATE TABLE IF NOT EXISTS `salonebooking` (
  `sbid` int(50) NOT NULL AUTO_INCREMENT,
  `bname` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phno` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL,
  `status` int(50) NOT NULL,
  PRIMARY KEY (`sbid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `salonebooking`
--

INSERT INTO `salonebooking` (`sbid`, `bname`, `location`, `name`, `phno`, `date`, `time`, `status`) VALUES
(5, 'balu', 'kakkanad', 'gayathri', '', '2019-02-24', '10', 1),
(6, 'aneeja', 'thrissur', 'gayathri', '', '2019-03-10', '2', 1),
(7, '', 'kakkanad', 'gayathri', '653768798', '2019-02-07', '2', 1),
(8, 'qa', 'kakkanad', 'gayathri', '86061132858', '2019-02-26', '2', 1),
(9, 'Jerin mathai', 'kakkanad', 'gayathri', '9747724162', '2019-02-08', '2:10', 1),
(10, 'keerthi', 'kakkanad', 'ikki', '653768798', '2019-02-12', '2:10', 1),
(11, 'keerthi', 'kakkanad', 'yoyo', '9856471230', '2020-12-18', '9am', 0);

-- --------------------------------------------------------

--
-- Table structure for table `salonreg`
--

CREATE TABLE IF NOT EXISTS `salonreg` (
  `sid` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `contactno` varchar(100) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `license` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `aboutus` varchar(100) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `salonreg`
--

INSERT INTO `salonreg` (`sid`, `name`, `type`, `contactno`, `emailid`, `address`, `license`, `location`, `username`, `password`, `image`, `aboutus`) VALUES
(4, 'gayathri', ' female', '9665556787', 'gayathri@gmail.com', 'kochi kakkanad', '1022', 'kakkanad', 'gayathri', '1234', 'th (2).jpg', 'jgvskh sgvjhkb'),
(5, 'ikki', ' female', '4344545345', 'jerinmathai04@gmail.com', 'dfcgvbhjn', '56', 'kakkanad', 'aa', '1234', 'vv.jpg', 'yvgubhjnk'),
(6, 'lookme', 'male', '9876543210', 'look@gmail.com', 'rajakkad', '98', 'ponmudiroad', 'look', '1221', 'IMG_2174-1024x768.jpg', 'niceservice'),
(7, 'gdrydyrd', ' female', '2545665666', 'hgftdf@gmail.com', 'dfdrnsdsdsdgd', '21545', 'vgfc', 'tj', '333', 'AA.jpg', 'jhkjhuig'),
(8, 'yoyo', 'male', '9876543211', 'yoyo@gmail.com', 'kaloor', '213', 'kochi', 'yoyo', '4444', 'hair-care8.jpg', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `stylemen`
--

CREATE TABLE IF NOT EXISTS `stylemen` (
  `smid` int(50) NOT NULL AUTO_INCREMENT,
  `stylemen` varchar(50) NOT NULL,
  PRIMARY KEY (`smid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `stylemen`
--

INSERT INTO `stylemen` (`smid`, `stylemen`) VALUES
(1, 'dui'),
(3, 'low fade'),
(4, 'midfade'),
(5, 'highfade'),
(6, 'quiff haircut'),
(7, 'pompadom');

-- --------------------------------------------------------

--
-- Table structure for table `stylewomen`
--

CREATE TABLE IF NOT EXISTS `stylewomen` (
  `swid` int(50) NOT NULL AUTO_INCREMENT,
  `stylewomen` varchar(50) NOT NULL,
  PRIMARY KEY (`swid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `stylewomen`
--

INSERT INTO `stylewomen` (`swid`, `stylewomen`) VALUES
(1, 'u'),
(2, 'v'),
(3, 'step');
