<?php
include'connect.php';
$id=$_GET['id'];
$qry="select pname from parlour where location='$id'";
echo '<option>Select parlour</option>';
			$rs=mysql_query($qry);
				while($res=mysql_fetch_array($rs))
			{  
			echo'<option value='.$res['pname'].'>'.$res['pname'].'</option>';
			}
?>