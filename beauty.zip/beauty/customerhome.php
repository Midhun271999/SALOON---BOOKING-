<!--A Design by W3layouts
  Author: W3layout
  Author URL: http://w3layouts.com
  License: Creative Commons Attribution 3.0 Unported
  License URL: http://creativecommons.org/licenses/by/3.0/
  -->
<!DOCTYPE html>
<html lang="zxx">
  <head>
    <title>Beautify Category Flat Bootstrap Responsive web Template| Home :: w3layouts</title>
    <!--meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Beautify Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
      Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script>
      addEventListener("load", function () {
      	setTimeout(hideURLbar, 0);
      }, false);
      
      function hideURLbar() {
      	window.scrollTo(0, 1);
      }
    </script>
    <!--//meta tags ends here-->
    <!--booststrap-->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <!--//booststrap end-->
    <!-- font-awesome icons -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- //font-awesome icons -->
    <!--stylesheets-->
    <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
    <!--//stylesheets-->
    <link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Raleway:300,400,500,700" rel="stylesheet">
  </head>
  <body>
    <div class="header-outs" id="home">
      <div class="header-w3layouts">
        <!--//navigation section -->
        <!-- nav -->
        <nav >
          <div id="logo">
            <h1><a href="customerhome.php">Saloonist</a></h1>
          </div>
          <label for="drop" class="toggle">Menu</label>
          <input type="checkbox" id="drop">
          <ul class="menu mt-2">
           <li class="active"><a href="customerhome.php">Home</a></li>
            <li><a href="viewcustomerprofile.php">profile</a></li>
              
             
           
            <li class="mx-lg-3 mx-md-2 my-md-0 my-1">
              <!-- First Tier Drop Down -->
              <label for="drop-2" class="toggle toogle-2">booking <span class="fa fa-angle-down" aria-hidden="true"></span>
              </label>
              <a href="#">booking <span class="fa fa-angle-down" aria-hidden="true"></span></a>
              <input type="checkbox" id="drop-2">
              <ul>
                
                <li><a href="parlourbooking.php" class="drop-text">New Booking</a></li>
                 <li><a href="custviewparlourbooking.php" class="drop-text">My bookings</a></li>
              </ul>
            </li>
            
            
              
           <li><a href="feedback.php">feedback</a></li>
             <li><a href="login.php">logout</a></li>
          </ul>
        </nav>
        <!-- //nav -->
      </div>
      <div class="slider">
        <div class="slider-img">
          <div class="container">
            <div class="slider-info ">
              <h5></h5>
              <div class="bottom-info">
               
              </div>
              <div class="outs_more-buttn">
                
              </div>
            </div>
          </div>
        </div>
        <!-- This is here just to demonstrate the callbacks -->
        <!-- <ul class="events">
          <li>Example 4 callback events</li>
          </ul>-->
        <div class="clearfix"></div>
      </div>
    </div>
    <!-- //banner -->
    <!--about -->
   
    <footer>
      <div class="footer-bottom py-lg-4 py-3 text-center">
        <p>©2019 Pets-paw. All Rights Reserved | Design by <a href="http://www.W3Layouts.com" target="_blank">W3Layouts</a></p>
        <div class="icons text-center mt-3">
          <ul>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-facebook"></span></a></div></li>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-twitter"></span></a></div></li>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-rss"></span></a></div></li>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-vk"></span></a></div></li>
          </ul>
        </div>
        <!-- move-top -->
        <div class="text-center">
          <a href="#home" class="move-top text-center mt-3"></a>
        </div>
        <!--//move-top -->
      </div>
    </footer>
    <!-- //Footer -->
  </body>
</html>