<!--A Design by W3layouts
  Author: W3layout
  Author URL: http://w3layouts.com
  License: Creative Commons Attribution 3.0 Unported
  License URL: http://creativecommons.org/licenses/by/3.0/
  -->
<!DOCTYPE html>
<html lang="zxx">
  <head>
  <?php
  include'connect.php';
  
   session_start();
		$uname= $_SESSION["username"];
		$query="select cid from customerreg where username='$uname'";
		//echo $query;
		$rs=mysql_query($query);
		$row=mysql_fetch_array($rs);
		?>
  
    <title>Beautify Category Flat Bootstrap Responsive web Template|contact :: w3layouts</title>
    <!--meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Beautify Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
      Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script>
      addEventListener("load", function () {
      	setTimeout(hideURLbar, 0);
      }, false);
      
      function hideURLbar() {
      	window.scrollTo(0, 1);
      }
    </script>
    <!--//meta tags ends here-->
    <!--booststrap-->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <!--//booststrap end-->
    <!-- font-awesome icons -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- //font-awesome icons -->
    <!--stylesheets-->
    <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
    <!--//stylesheets-->
    <link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Raleway:300,400,500,700" rel="stylesheet">
  </head>
<body>
    <!--headder-->
    <div class="header-outs inner_page-banner " id="home">
      <div class="header-w3layouts">
        <!--//navigation section -->
        <!-- nav -->
        <nav >
          <div id="logo">
            <h1><a href="customerhome.php">Saloonist</a></h1>
          </div>
          <label for="drop" class="toggle">Menu</label>
          <input type="checkbox" id="drop">
          <ul class="menu mt-2">
            <li class="active"><a href="customerhome.php">Home</a></li>
            <li><a href="viewcustomerprofile.php">profile</a></li>
              
             
           
            <li class="mx-lg-3 mx-md-2 my-md-0 my-1">
              <!-- First Tier Drop Down -->
              <label for="drop-2" class="toggle toogle-2">booking <span class="fa fa-angle-down" aria-hidden="true"></span>
              </label>
              <a href="#">booking <span class="fa fa-angle-down" aria-hidden="true"></span></a>
              <input type="checkbox" id="drop-2">
              <ul>
                <li><a href="saloonbooking.php" class="drop-text">saloon</a></li>
                <li><a href="parlourbooking.php" class="drop-text">parlour</a></li>
              </ul>
            </li>
            
            
               <li class="mx-lg-3 mx-md-2 my-md-0 my-1">
              <!-- First Tier Drop Down -->
              <label for="drop-2" class="toggle toogle-2">viewbooking <span class="fa fa-angle-down" aria-hidden="true"></span>
              </label>
              <a href="#">viewbooking <span class="fa fa-angle-down" aria-hidden="true"></span></a>
              <input type="checkbox" id="drop-2">
              <ul>
                <li><a href="custviewsaloonbooking.php" class="drop-text">saloon</a></li>
                <li><a href="custviewparlourbooking.php" class="drop-text">parlour</a></li>
              </ul>
            </li>
           <li><a href="feedback.php">feedback</a></li>
             <li><a href="login.php">logout</a></li>
          </ul>
        <!-- //nav -->
      </div>
    </div>
    <!-- //Navigation -->
    <!--//headder-->
    <!-- short -->
    <div class="using-border py-3">
      <div class="inner_breadcrumb  ml-4">
        <ul class="short_ls">
          <li>
            <a href="customerhome.php">Home</a>
            <span>/ /</span>
          </li>
          <li>Feedback</li>
        </ul>
      </div>
    </div>
    <!-- //short-->
    <!--contact -->
    <section class="contact py-lg-4 py-md-3 py-sm-3 py-3">
      <div class="container-fluid pt-lg-5 pt-md-4 pt-sm-4 pt-3">
        <h3 class="title text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">FEEDBACK</h3>
        <div class="row w3pvt-info-para">
          <!--contact-map -->
          <div class="col-lg-6 col-md-6">
           
           
           <form id="form1" name="form1" method="post" action="">
  FEEDBACK
  <table width="267" border="1">
    <tr>
      <td width="82">Date</td>
      <td width="169"><label>
        <input name="Date" type="text" id="Date" value="<?php echo Date("y-m-d");?>"/>
      </label></td>
    </tr>
    <tr>
      <td>Customer ID </td>
      <td><input name="cid" type="text" required id="cid" value="<?php if(!empty($row['cid'])){echo $row['cid'];}?>" /> </td>
    </tr>
   
    <tr>
      <td>Feedback</td>
      <td><label>
        <textarea name="Feedback" required id="Feedback"></textarea>
      </label></td>
    </tr>
  </table>
  <label>
  <input type="submit" name="Submit" value="Submit" />
  </label>
   <?php
  if(isset($_REQUEST["Submit"]))
  {
  mysql_connect("localhost","root","");
  mysql_select_db("beauty");
  $date=$_REQUEST["Date"];
  $cid=$_REQUEST["cid"];
 
  $feedback=$_REQUEST["Feedback"];
  
   mysql_query("insert into feedback values('$date','$cid','$feedback')");
  }	
	?>


</form>
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	
			
          </div>
          <!--//contact-map -->
          <!--contact-form-->
          <div class="col-lg-6 col-md-6 contact-form "></div>
        </div>
        <!--//contact-map -->
      </div>
    </section>
    <!--//contact  -->
    <!--Footer -->
    <section class="buttom-footer py-lg-4 py-md-3 py-sm-3 py-3"></section>
    <footer>
      <div class="footer-bottom py-lg-4 py-3 text-center">
        <p>©2019 Pets-paw. All Rights Reserved | Design by <a href="http://www.W3Layouts.com" target="_blank">W3Layouts</a></p>
        <div class="icons text-center mt-3">
          <ul>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-facebook"></span></a></div></li>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-twitter"></span></a></div></li>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-rss"></span></a></div></li>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-vk"></span></a></div></li>
          </ul>
        </div>
        <!-- move-top -->
        <div class="text-center">
          <a href="#home" class="move-top text-center mt-3"></a>
        </div>
        <!--//move-top -->
      </div>
    </footer>
    <!-- //Footer -->
</body>
</html>