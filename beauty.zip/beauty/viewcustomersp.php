<!--A Design by W3layouts
  Author: W3layout
  Author URL: http://w3layouts.com
  License: Creative Commons Attribution 3.0 Unported
  License URL: http://creativecommons.org/licenses/by/3.0/
  -->
  <!DOCTYPE html>
<html lang="zxx">
  <head>
  <?php
  include'connect.php';
  ?>
    <title>Beautify Category Flat Bootstrap Responsive web Template|contact :: w3layouts</title>
    <!--meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Beautify web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
      Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script>
      addEventListener("load", function () {
      	setTimeout(hideURLbar, 0);
      }, false);
      
      function hideURLbar() {
      	window.scrollTo(0, 1);
      }
    </script>
    <!--//meta tags ends here-->
    <!--booststrap-->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
    <!--//booststrap end-->
    <!-- font-awesome icons -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- //font-awesome icons -->
    <!--stylesheets-->
    <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
    <!--//stylesheets-->
    <link href="//fonts.googleapis.com/css?family=Oswald:300,400,500,600" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Raleway:300,400,500,700" rel="stylesheet">
  </head>
<body>
    <!--headder-->
    <div class="header-outs inner_page-banner " id="home">
      <div class="header-w3layouts">
        <!--//navigation section -->
        <!-- nav -->
       <!-- nav -->
       <a href="viewfeedback.php"></a>
       <nav >
          <div id="logo">
            <h1><a href="index.html">Saloonist</a></h1>
          </div>
          <label for="drop" class="toggle">Menu</label>
          <input type="checkbox" id="drop">
          <ul class="menu mt-2">
          <li class="active"><a href="adminhome.php">Home</a></li>
            <li class="active"><a href="viewparlour.php">Parlor</a></li>
            <li class="active"><a href="viewcustomersp.php">Customers</a></li>
            <li class="active"><a href="adminbooking.php">Bookings</a></li>
            <li class="active"><a href="viewfeedback.php">feedback</a></li>
             <li class="active"><a href="login.php"> logout</a></li>
          </ul>
        </nav>
        <!-- //nav -->
      </div>
    </div>
    <!-- //Navigation -->
    <!--//headder-->
    <!-- short -->
    <div class="using-border py-3">
      <div class="inner_breadcrumb  ml-4">
        <ul class="short_ls">
          <li>
            <a href="parlourhome.php">Home</a>
            <span>/ /</span>
          </li>
          <li>Profile</li>
        </ul>
      </div>
    </div>
    <!-- //short-->
    <!--contact -->
    <section class="contact py-lg-4 py-md-3 py-sm-3 py-3">
      <div class="container-fluid pt-lg-5 pt-md-4 pt-sm-4 pt-3">
        <h3 class="title text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3">PROFILE</h3>
        <div class="row w3pvt-info-para">
          <!--contact-map -->
          <div class="col-lg-6 col-md-6">
           
          
            <form action="#" method="post">
              <div class=" w3pvt-wls-contact-mid">
                <div class="form-group contact-forms">
                 
                 
                 
                 
                 
                 
                 
                 
                 
                   <?php
	 $y="select * from customerreg";
	 $sql=mysql_query($y);
					  
	?>
    <table>
      <table border="2">
    	<tr>
    		<th>CID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
    		<th>FIRSTNAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
            <th>LASTNAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
             <th>DOB&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
               <th>GENDER&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
               <th>PHONENUMBER&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
   
    		 
    	</tr>
    	<?php
		while($k=mysql_fetch_array($sql))
		{
		
		?>
        <tr>
        	<td><?php echo $k['cid']; ?></td>
        	<td><?php echo $k['firstname']; ?></td>
                    	<td><?php echo $k['lastname']; ?></td>
        	
        	 	<td><?php echo $k['dob']; ?></td>
                	<td><?php echo $k['gender']; ?></td>
                    
                    
                    <td><?php echo $k['phno']; ?></td>
                   
                    
                   
            
        </tr>
        <?php
			}
		?>
    </table>
                 
                                      

                 
              </form>      
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
		 
		 
		 
		 
	
			
          </div>
          <!--//contact-map -->
          <!--contact-form-->
          <div class="col-lg-6 col-md-6 contact-form "></div>
        </div>
        <!--//contact-map -->
      </div>
    </section>
    <!--//contact  -->
    <!--Footer -->
    <section class="buttom-footer py-lg-4 py-md-3 py-sm-3 py-3"></section>
    <footer>
      <div class="footer-bottom py-lg-4 py-3 text-center">
        <p>©2019 Pets-paw. All Rights Reserved | Design by <a href="http://www.W3Layouts.com" target="_blank">W3Layouts</a></p>
        <div class="icons text-center mt-3">
          <ul>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-facebook"></span></a></div></li>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-twitter"></span></a></div></li>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-rss"></span></a></div></li>
            <li><div class="footer-bg "><a href="#"><span class="fa fa-vk"></span></a></div></li>
          </ul>
        </div>
        <!-- move-top -->
        <div class="text-center">
          <a href="#home" class="move-top text-center mt-3"></a>
        </div>
        <!--//move-top -->
      </div>
    </footer>
    <!-- //Footer -->
</body>
</html>