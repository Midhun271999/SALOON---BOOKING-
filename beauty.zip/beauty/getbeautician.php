<?php
include'connect.php';
$id=$_GET['id'];
$qry="select name from beautition where pname='$id'";
echo '<option>Select beautician</option>';
			$rs=mysql_query($qry);
				while($res=mysql_fetch_array($rs))
			{  
			echo'<option value='.$res['name'].'>'.$res['name'].'</option>';
			}
			
			 ?>